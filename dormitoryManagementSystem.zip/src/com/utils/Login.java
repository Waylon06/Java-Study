package com.utils;

import com.pojo.Student;

public class Login {
    public void login(){
//        String ;
//        String password;
//        System.out.println("请输入账号:");
//        username = "student";
//        password = "";
        Student student = new Student();
        System.out.println(student);
    }
}
